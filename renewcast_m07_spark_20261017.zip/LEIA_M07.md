# Renewcast — M07.1

Cliente Windows 1.1 aceito em E94. A unidade seguinte é a transformação de dados ONS em DuckDB/PySpark/Spark SQL.

1. Extraia este pacote na raiz `C:\renewable-forecast-lab`.
2. Abra o Docker Desktop e execute `python scripts/executar_m07_spark.py`.
3. Leia `docs/Aula_M07_1_Spark_DuckDB.md`.
4. Implemente as duas partes de `notebooks/transformacao_spark.py`.
5. Execute `python scripts/executar_m07_spark.py --autoria`.
6. Compare partições com `python scripts/executar_m07_spark.py --autoria --shuffle-partitions 4` e escreva seu parecer.

O modo guiado funciona antes de implementar a autoria. Não é necessário iniciar a API nem instalar Spark no Conda. O primeiro build Docker baixa centenas de MB. A entrada padrão é `data/interim/CJU_BA5EIGT_hourly.parquet`, preservada em leitura.

Núcleo conferido pelo professor em Linux nativo com dados sintéticos. Execução Docker/Windows com sua série real ainda será recebida. O ZIP não contém dados ONS nem uma implementação preenchida da sua autoria.

Arquivos novos desta unidade: `scripts/executar_m07_spark.py`, `tools/m07_transformacao.py`, `notebooks/transformacao_spark.py`, `infra/m07_spark/` e documentos da aula. A cópia do roteiro em `docs/` foi atualizada para 1.52. O pacote não altera o cliente, a API ou o modelo anteriores.

Extraia uma vez antes de editar. Uma nova extração com `-Force` substituiria o arquivo de autoria do pacote; preserve sua versão caso precise reextrair.
