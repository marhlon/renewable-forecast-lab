"""M06: leitura do benchmark e autoria da escolha sob latencia e vazao.

Executar: python notebooks/analise_concorrencia.py
Depois implementar escolher_concorrencia e executar com --autoria.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
RUN_ROOT = PROJECT / "reports/performance/CJU_BA5EIGT/h24_event_concurrency_v1"


def escolher_concorrencia(fases: list[dict], teto_ms: float, fracao: float) -> dict:
    """SUA ENTREGA: implementar a decisao sem alterar o cliente de carga.

    Cada elemento e uma linha numerica de summary.csv.
    1. Considere cada concurrency em (1, 4, 8), com as tres rodadas presentes.
    2. Uma opcao e elegivel se, EM TODAS as rodadas, failed == 0 e
       p95_correct_ms e finito e <= teto_ms. Ausente nunca significa zero.
    3. Calcule a mediana de correct_per_second das tres rodadas por opcao.
    4. Entre as elegiveis, obtenha a maior mediana. Escolha a MENOR
       concorrencia cuja mediana alcance pelo menos fracao desse valor.
    5. Sem opcao elegivel: concurrency=None, com justificativa.

    Retorne {"concurrency": int ou None, "reason": str nao vazia}.
    Nao fixe a resposta em 1, 4 ou 8 e nao misture vazao com latencia.
    A justificativa deve citar a mediana e o pior P95 da opcao escolhida,
    ou informar a ausencia de opcao que cumpra a regra.
    """
    raise NotImplementedError("Implemente escolher_concorrencia conforme o contrato acima e a aula.")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def carregar(run_dir=None):
    if run_dir is None:
        pointer = json.loads((RUN_ROOT / "latest_run.json").read_text(encoding="utf-8"))
        run_dir = Path(pointer["directory"])
        if not run_dir.is_absolute() or sha(run_dir / "verification.json") != pointer["verification_sha256"]:
            raise ValueError("Ponteiro de execucao invalido.")
    run_dir = Path(run_dir).resolve()
    receipt = json.loads((run_dir / "verification.json").read_text(encoding="utf-8"))
    if receipt.get("schema") != "renewcast-concurrency-receipt-v1" or receipt.get("measurement_complete") is not True:
        raise ValueError("A medicao nao esta completa. Leia failure.json/pipeline.log.")
    for name, expected in receipt["output_sha256"].items():
        path = (run_dir / name).resolve()
        if not path.is_relative_to(run_dir) or sha(path) != expected:
            raise ValueError(f"Evidencia alterada: {name}")
    with (run_dir / "summary.csv").open(encoding="utf-8", newline="") as handle:
        raw = list(csv.DictReader(handle))
    phases = [{k: None if value == "" else float(value) for k, value in row.items()} for row in raw]
    keys = [(row["round"], row["concurrency"]) for row in phases]
    if len(keys) != 9 or set(keys) != {(r, c) for r in (1, 2, 3) for c in (1, 4, 8)}:
        raise ValueError("Sao necessarias nove fases distintas: tres rodadas por concorrencia.")
    protocol = json.loads((run_dir / "protocol.json").read_text(encoding="utf-8"))
    for row in phases:
        if row["attempts"] != protocol["calls_per_phase"] or row["correct_200"] + row["failed"] != row["attempts"]:
            raise ValueError("Contagens nao reconciliadas.")
    return run_dir, phases, protocol


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--autoria", action="store_true")
    args = parser.parse_args(argv)
    run_dir, phases, protocol = carregar(args.run_dir)
    print(f"Execucao: {run_dir}")
    print("rodada clientes corretas falhas vazao_correta/s p50_ms p95_ms")
    for row in sorted(phases, key=lambda r: (r["round"], r["concurrency"])):
        p50 = "indefinido" if row["p50_correct_ms"] is None else f"{row['p50_correct_ms']:.2f}"
        p95 = "indefinido" if row["p95_correct_ms"] is None else f"{row['p95_correct_ms']:.2f}"
        print(f"{int(row['round']):6} {int(row['concurrency']):8} {int(row['correct_200']):8} {int(row['failed']):6} "
              f"{row['correct_per_second']:15.2f} {p50:>6} {p95:>6}")
    if args.autoria:
        rules = protocol["exploratory_rule"]
        try:
            choice = escolher_concorrencia(phases, rules["p95_ms_max"], rules["throughput_retained_fraction"])
        except NotImplementedError as exc:
            parser.error(str(exc))
        if not isinstance(choice, dict) or set(choice) != {"concurrency", "reason"}:
            raise ValueError("Retorne exatamente concurrency e reason.")
        if choice["concurrency"] is not None and (type(choice["concurrency"]) is not int or choice["concurrency"] not in (1, 4, 8)):
            raise ValueError("concurrency deve ser 1, 4, 8 ou None.")
        if not isinstance(choice["reason"], str) or not choice["reason"].strip():
            raise ValueError("Fundamente a decisao em reason.")
        output = run_dir / "autoria"
        output.mkdir(exist_ok=True)
        result = {"source_verification_sha256": sha(run_dir / "verification.json"),
                  "code_sha256": sha(Path(__file__)), "choice": choice,
                  "rules": rules, "operational_policy_approved": False,
                  "review_status": "format_checked_semantics_pending_teacher_review"}
        (output / "decisao.json").write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
        print(json.dumps(choice, ensure_ascii=False, indent=2))
        print(f"Formato conferido; a logica sera revisada. Salvo: {output / 'decisao.json'}")
    else:
        print("Proxima autoria: implementar escolher_concorrencia; executar com --autoria e escrever parecer_concorrencia.md.")
        print("Nao use media dos P95 como P95 agregado. O protocolo e local, fechado e com um pedido repetido.")


if __name__ == "__main__":
    main()
